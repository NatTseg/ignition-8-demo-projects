def getData(tagPath):
	source=["*:/tag:%s*" %tagPath]
	alarmData = system.alarm.queryStatus(source=source)
	return alarmData
	
def getProps(tagPath, asDataset=False):
	data = getData(tagPath)
	
	
	# alert active - if any alert is active
	# alarm highest unack priority - highest of alert active
	# alarm active time - time of highest active alert
	
	alertActive = False
	highestUnackPriority = 0
	now = system.date.now()
	activeTime = now
	lastAlarm = 0
	
	for alarm in data:
		if not alarm.cleared:
			alertActive = True
			if not alarm.acked and alarm.priority.ordinal() > highestUnackPriority:
				highestUnackPriority = alarm.priority.ordinal()
				activeTime = system.date.fromMillis(alarm.activeData.timestamp)
		if alarm.activeData.timestamp > lastAlarm:
			lastAlarm = alarm.activeData.timestamp
			
	if lastAlarm > 0:
		lastAlarm = system.date.fromMillis(lastAlarm)
	
	if asDataset:
		headers = ['alertActive', 'alarmHighestUnackPriority', 'alertActiveTime', 'lastAlarm']
		data = [[alertActive, highestUnackPriority, activeTime, lastAlarm]]
		return system.dataset.toDataSet(headers, data)
	else:
		return {'alertActive': alertActive, 'alarmHighestUnackPriority': highestUnackPriority, 'alertActiveTime': activeTime, 'lastAlarm': lastAlarm}
	
	
	
def getAlarms(self, value, app=None):
	states = []
	for i in range(len(self.custom.states)):
		states.append(self.custom.states[i])
	alarms = system.alarm.queryStatus(state=states, all_properties=[('App', '=', app)])
	data = []
	for alarm in alarms:
		displayPath = alarm.getDisplayPath()
		priority = alarm.getPriority()
		priorityOrdinal = alarm.getPriority().ordinal()
		state = alarm.getState().ordinal() #0=ClearUnacked, 1=ClearAcked, 2=ActiveUnacked, 3=ActiveAcked
		stateOrder = [1,0,3,2].index(state)
		id = alarm.getId()
		name = alarm.getName()
		
		timestamp = None
		timestampMS = None
		eventValue = None
		
		active = {}
		if alarm.getActiveData() != None:
			for prop in alarm.getActiveData().getValues():
				active[prop.getProperty().getName()] = prop.getValue()
			
		clear = {}
		if alarm.getClearedData() != None:
			for prop in alarm.getClearedData().getValues():
				clear[prop.getProperty().getName()] = prop.getValue()
		
		stateDict = active if state in [2,3] else clear
		if "eventTime" in stateDict:
			timestamp = system.date.format(stateDict["eventTime"], "M/d/yy hh:mm:ss a")
			timestampMS = stateDict["eventTime"]
		
		if "eventValue" in stateDict:
			eventValue = str(stateDict["eventValue"])
		
		ack = {"isAcked":False, "id":id}
		if state in [1,3]:
			ack["isAcked"] = True
			for prop in alarm.getAckData().getValues():
				propValue = str(prop.getValue())
				if prop.getProperty().getName() == "eventTime":
					propValue = system.date.format(prop.getValue(), "M/d/yy hh:mm:ss a")
				ack[prop.getProperty().getName()] = propValue
		ack = system.util.jsonEncode(ack)
		
		data.append({"id":id, "displayPath":displayPath, "name":name, "priority":priority, "priorityOrdinal":priorityOrdinal, "state":state, "stateOrder":stateOrder, "timestamp":timestamp, "timestampMS":timestampMS, "value":eventValue, "ack":ack})
	
	data.sort(key=lambda x: (x["stateOrder"], x["priorityOrdinal"], x["timestampMS"]), reverse=True)
	return data