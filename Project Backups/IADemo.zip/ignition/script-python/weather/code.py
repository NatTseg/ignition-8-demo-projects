def updateWeather(station):
		"""		
		Arguments:
			self: A reference to the component that is invoking this function.
		"""
		#def doAsynch():
		
		
		import system
		import xml.etree.ElementTree as ET

		url = "https://w1.weather.gov/xml/current_obs/%s.xml" %station
	
		#try:
		response = system.net.httpGet(url)
	
		# store current and forecast data in datasets
		currentHeader = ["location", "temp", "humidity", "wind", "date", "icon", "condition"]
		currentData = [["", "", "", "", "", "", ""]]
	
		observation = ET.fromstring(response)
		currentData[0][0] = observation.find("location").text
		currentData[0][1] = float(observation.find("temp_f").text)
		currentData[0][2] = float(observation.find("relative_humidity").text)
	
		try:
			wind_dir = observation.find("wind_dir").text
			currentData[0][3] = observation.find("wind_mph").text + " mph " + wind_dir
		except:
			currentData[0][3] = "Not Measured"
			
		currentData[0][4] = observation.find("observation_time_rfc822").text
		url_base = observation.find("icon_url_base").text if observation.find("icon_url_base") is not None else ""
		currentData[0][5] = (url_base + observation.find("icon_url_name").text) if observation.find("icon_url_name") is not None else ""
		currentData[0][6] = observation.find("weather").text
		# push data to datasets
		#def doLater(currentHeader=currentHeader, currentData=currentData):
			#import system
		weatherDataset = system.dataset.toDataSet(currentHeader, currentData)
			#self.live = 1
		#system.util.invokeLater(doLater)
		return weatherDataset
		#except:
			#def doLater():
			#	import system
				#self.live = 0
			#system.util.invokeLater(doLater)
			#system.util.invokeAsynchronous(doAsynch)
		#	return None